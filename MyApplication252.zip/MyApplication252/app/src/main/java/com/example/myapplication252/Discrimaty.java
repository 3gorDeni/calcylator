package com.example.myapplication252;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;

public class Discrimaty extends AppCompatActivity {

    EditText et_A, et_B, et_C;
    Button button2;
    TextView tv_result;
    double a, b, c, d, x1, x2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discrimaty);
        et_A = (EditText) findViewById(R.id.et_A);
        et_B = (EditText) findViewById(R.id.et_B);
        et_C = (EditText) findViewById(R.id.et_C);

        button2 = (Button) findViewById(R.id.button2);

        tv_result = (TextView) findViewById(R.id.tv_result);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!et_A.getText().toString().equals("") && !et_B.getText().toString().equals("") && !et_C.getText().toString().equals("")) {
                    a = Double.parseDouble(et_A.getText().toString());
                    b = Double.parseDouble(et_B.getText().toString());
                    c = Double.parseDouble(et_C.getText().toString());
                    d = Math.pow(b, 2) - 4 * a * c;
                    if (d == 0) {
                        x1 = -b / (2 * a);
                        tv_result.setText("d =" + d + "\nx = " + x1);
                    } else if (d < 0) {
                        tv_result.setText("Нет корней");
                    } else if (d > 0) {
                        x1 = (-b + Math.sqrt(d)) / (2 * a);
                        x2 = (-b + Math.sqrt(d)) / (2 * a);
                        tv_result.setText("d =" + d + "\nx1 = " + x1 + "\nx2 = " + x2);
                    }
                }
            }
        });
    }
}

